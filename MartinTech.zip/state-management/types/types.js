export const ADMIN_DATA = "ADMIN_DATA";

export const GET_ERRORS = "GET_ERRORS";
