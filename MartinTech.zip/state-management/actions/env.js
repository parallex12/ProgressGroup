export const firebaseConfig = {
  apiKey: "AIzaSyC7vm2z6wzH9Yi7IIjOrq6uAzTqvbBeo74",
  authDomain: "progress-group-f351a.firebaseapp.com",
  projectId: "progress-group-f351a",
  storageBucket: "progress-group-f351a.appspot.com",
  messagingSenderId: "344315806986",
  appId: "1:344315806986:web:30e5a9295a7582eef226f3",
};
